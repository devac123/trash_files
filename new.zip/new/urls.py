from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('\imagepost',views.imagepost1,name="imagepost1")
]