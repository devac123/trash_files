import re

from django.shortcuts import render
import requests
from bs4 import BeautifulSoup

#Getting news from GNDEC
print('hello')

gne_n=requests.get("https://www.gndec.ac.in/")
gne_soup= BeautifulSoup(gne_n.content,'html5lib')

gne_div=gne_soup.find('div',{'id':'sidebar-last'})
gne_span=gne_div.find_all('span')
gne_gethead=[]
gne_getpara=[]
gne_getdiv=[]
for gd in gne_span:
    gne_gethead.append(gd.text)
# print("new",gne_gethead)


# GEtting news from Times of India

toi_r = requests.get("https://timesofindia.indiatimes.com/briefs")
toi_soup = BeautifulSoup(toi_r.content, 'html5lib')

toi_headings = toi_soup.find_all('h2')

toi_headings = toi_headings[0:-13] # removing footers

toi_news = []
toi_img_cont=[]
for th in toi_headings:
    toi_news.append(th.text)

toi_images=toi_soup.find_all('img')
# divImage = toi_soup.find('div', {"class": "posrel"})
# imgsrc=divImage.find_all('img')
# close the browser
for im in toi_images:
    toi_img_cont.append(im.get('data-src'))
# print(toi_img_cont)

# images = toi_soup.find_all('img', {'src':re.compile('.cms')})
# for image in images:
#     toi_img_cont.append(image['data-src'])
#     # print(image['src']+'\n')
# print(toi_img_cont)

ht_r = requests.get("https://www.hindustantimes.com/india-news/")
ht_soup = BeautifulSoup(ht_r.content, 'html5lib')
ht_headings = ht_soup.findAll("div", {"class": "headingfour"})
ht_headings = ht_headings[2:]
ht_news = []

for hth in ht_headings:
    ht_news.append(hth.text)


#top news
ht_top = requests.get("https://www.hindustantimes.com/india-news/")
ht_topsoup = BeautifulSoup(ht_top.content, 'html5lib')

httop_news_div = ht_topsoup.find('ul',class_ = 'latest-news-morenews more-latest-news more-separate newslist-sec')
ht_a=httop_news_div.findAll('img')
ht_topnews_h = []
ht_topnews_img=[]


for im in ht_a:
    ht_topnews_img.append(im.get('src'))
    ht_topnews_h.append(im.get('title'))
# print(ht_topnews_h)
# print(ht_topnews_img)
ht_a_forurl=httop_news_div.findAll('a')
ht_topnews_a=[]
for im in ht_a_forurl:
    ht_topnews_a.append(im.get('href'))
print(ht_topnews_a[0])
b=ht_topnews_a[0]
# print(b)
ht_for_a_link=requests.get(b)
# print(ht_for_a_link)
ht_anchorsoup = BeautifulSoup(ht_for_a_link.content, 'html5lib')
httop_news_para = ht_anchorsoup.find("div", {"class": "storyDetail"})

ht_para=httop_news_para.find_all('p')
ht_topnews_para = []
for pp in ht_para:
    if(pp.text=='Read More'):
        print('not added')
    else:
        ht_topnews_para.append(pp.text)
print(ht_topnews_para)




def index(req):
    # return render(req,'testapp/index.html', {'res':res})
     return render(req, 'testapp/index.html', {'ht_img':ht_topnews_img, 'ht_heading': ht_topnews_h,'gne_news':gne_gethead})

# Create your views here.
def imagepost1(request):
    return render(request,'testapp/image-post.html',{'ht_img':ht_topnews_img, 'ht_heading': ht_topnews_h,'para_detail':ht_topnews_para})